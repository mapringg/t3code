'use client';

import React from 'react';
import {
  ImageResolvedAssetSource,
  StyleSheet,
  processColor,
} from 'react-native';
import TabsScreenAndroidNativeComponent, {
  type Appearance,
  type IconTinting,
  type ItemStateAppearance,
  type NativeProps as TabsScreenAndroidNativeComponentProps,
} from '../../../fabric/tabs/TabsScreenAndroidNativeComponent';
import type {
  TabsScreenAppearanceAndroid,
  TabsScreenItemStateAppearanceAndroid,
} from './TabsScreen.android.types';
import type { TabsScreenProps } from '../screen/TabsScreen.types';
import type { TabsScreenIconAndroid } from './TabsScreenIcon.types';
import { useTabsScreen } from './useTabsScreen';
import { parseAndroidIconToNativeProps } from '../../shared';

function TabsScreen(props: TabsScreenProps) {
  // ios props are safely dropped
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { android, ios, ...baseProps } = props;

  const componentNodeRef =
    React.useRef<React.Component<TabsScreenAndroidNativeComponentProps>>(null);

  const {
    onDidAppear,
    onDidDisappear,
    onWillAppear,
    onWillDisappear,
    children,
    style,
    ...filteredBaseProps
  } = baseProps;

  const { lifecycleCallbacks } =
    useTabsScreen<TabsScreenAndroidNativeComponentProps>({
      componentNodeRef,
      onDidAppear,
      onDidDisappear,
      onWillAppear,
      onWillDisappear,
      screenKey: filteredBaseProps.screenKey,
    });

  const iconProps = parseIconsToNativeProps(
    android?.icon,
    android?.selectedIcon,
  );

  return (
    <TabsScreenAndroidNativeComponent
      collapsable={false}
      style={[style, styles.fillParent]}
      // @ts-ignore - This is debug only anyway
      ref={componentNodeRef}
      {...lifecycleCallbacks}
      {...iconProps}
      {...filteredBaseProps}
      // Android-specific
      standardAppearance={mapAppearanceToNativeProps(
        android?.standardAppearance,
      )}>
      {children}
    </TabsScreenAndroidNativeComponent>
  );
}

function mapAppearanceToNativeProps(
  appearance?: TabsScreenAppearanceAndroid,
): Appearance | undefined {
  if (!appearance) return undefined;

  const {
    tabBarBackgroundColor,
    tabBarItemRippleColor,
    normal,
    selected,
    focused,
    disabled,
    tabBarItemActiveIndicatorColor,
    tabBarItemTitleFontWeight,
    tabBarItemBadgeBackgroundColor,
    tabBarItemBadgeTextColor,
    ...rest
  } = appearance;

  return {
    ...rest,
    tabBarBackgroundColor: processColor(tabBarBackgroundColor),
    tabBarItemRippleColor: processColor(tabBarItemRippleColor),
    normal: mapItemStateAppearanceToNativeProp(normal),
    selected: mapItemStateAppearanceToNativeProp(selected),
    focused: mapItemStateAppearanceToNativeProp(focused),
    disabled: mapItemStateAppearanceToNativeProp(disabled),
    tabBarItemActiveIndicatorColor: processColor(
      tabBarItemActiveIndicatorColor,
    ),
    tabBarItemTitleFontWeight:
      tabBarItemTitleFontWeight !== undefined
        ? String(tabBarItemTitleFontWeight)
        : undefined,
    tabBarItemBadgeBackgroundColor: processColor(
      tabBarItemBadgeBackgroundColor,
    ),
    tabBarItemBadgeTextColor: processColor(tabBarItemBadgeTextColor),
  };
}

function mapItemStateAppearanceToNativeProp(
  itemStateAppearance?: TabsScreenItemStateAppearanceAndroid,
): ItemStateAppearance | undefined {
  if (!itemStateAppearance) return undefined;

  const { tabBarItemTitleFontColor, tabBarItemIconColor, ...rest } =
    itemStateAppearance;

  return {
    ...rest,
    tabBarItemTitleFontColor: processColor(tabBarItemTitleFontColor),
    tabBarItemIconColor: processColor(tabBarItemIconColor),
  };
}

function parseIconsToNativeProps(
  icon: TabsScreenIconAndroid | undefined,
  selectedIcon: TabsScreenIconAndroid | undefined,
): {
  imageIconResource?: ImageResolvedAssetSource | undefined;
  drawableIconResourceName?: string | undefined;
  iconTinting?: IconTinting | undefined;
  selectedImageIconResource?: ImageResolvedAssetSource | undefined;
  selectedDrawableIconResourceName?: string | undefined;
  selectedIconTinting?: IconTinting | undefined;
} {
  const parsedIcon = parseAndroidIconToNativeProps(icon);
  const parsedSelectedIcon = parseAndroidIconToNativeProps(selectedIcon);

  return {
    imageIconResource: parsedIcon.imageIconResource,
    drawableIconResourceName: parsedIcon.drawableIconResourceName,
    iconTinting: icon?.tinting,
    selectedImageIconResource: parsedSelectedIcon.imageIconResource,
    selectedDrawableIconResourceName:
      parsedSelectedIcon.drawableIconResourceName,
    selectedIconTinting: selectedIcon?.tinting,
  };
}

export default TabsScreen;

const styles = StyleSheet.create({
  fillParent: {
    position: 'absolute',
    flex: 1,
    width: '100%',
    height: '100%',
  },
});

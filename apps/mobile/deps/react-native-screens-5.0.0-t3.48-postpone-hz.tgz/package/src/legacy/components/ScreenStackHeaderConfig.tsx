'use client';

import React from 'react';
import {
  HeaderBarButtonItemMenuAction,
  HeaderBarButtonItemWithMenu,
  ScreenStackHeaderConfigProps,
  ScreenStackHeaderSubviewProps,
} from '../types';
import {
  Image,
  ImageProps,
  NativeSyntheticEvent,
  Platform,
  StyleSheet,
  View,
  ViewProps,
} from 'react-native';
import featureFlags from '../../flags';

// Native components
import ScreenStackHeaderConfigNativeComponent from '../../fabric/legacy/ScreenStackHeaderConfigNativeComponent';
import ScreenStackHeaderSubviewNativeComponent, {
  type NativeProps as ScreenStackHeaderSubviewNativeProps,
} from '../../fabric/legacy/ScreenStackHeaderSubviewNativeComponent';
import { prepareHeaderBarButtonItems } from './helpers/prepareHeaderBarButtonItems';
import { isHeaderBarButtonsAvailableForCurrentPlatform } from '../../utils';
import { useEdgeInsetApplication } from './contexts/EdgeInsetApplicationContext';

export const ScreenStackHeaderSubview: React.ComponentType<ScreenStackHeaderSubviewNativeProps> =
  ScreenStackHeaderSubviewNativeComponent;

// Nominal instance type for header config refs. `React.ComponentRef<typeof View>`
// declaration emit resolves down to the non-public `ReactNativeElement` class.
// An interface stops that resolution at a name this package can emit.
export interface ScreenStackHeaderConfigInstance
  extends React.ComponentRef<typeof View> {}

export const ScreenStackHeaderConfig = React.forwardRef<
  ScreenStackHeaderConfigInstance,
  ScreenStackHeaderConfigProps
>((props, ref) => {
  const {
    appliesTopInset,
    useLegacyBehavior,
    consumeLeftInset,
    consumeRightInset,
    consumeBottomInset,
  } = useEdgeInsetApplication(
    !props.hidden,
    props.disableTopInsetApplication ?? false,
    props.disableLeftInsetApplication ?? false,
    props.disableRightInsetApplication ?? false,
    props.disableBottomInsetApplication ?? false,
  );

  const {
    headerLeftBarButtonItems,
    headerRightBarButtonItems,
    headerCenterBarButtonItems,
    headerToolbarItems,
  } = props;

  const preparedHeaderLeftBarButtonItems =
    headerLeftBarButtonItems && isHeaderBarButtonsAvailableForCurrentPlatform
      ? prepareHeaderBarButtonItems(headerLeftBarButtonItems, 'left')
      : undefined;
  const preparedHeaderRightBarButtonItems =
    headerRightBarButtonItems && isHeaderBarButtonsAvailableForCurrentPlatform
      ? prepareHeaderBarButtonItems(headerRightBarButtonItems, 'right')
      : undefined;
  const preparedHeaderCenterBarButtonItems =
    headerCenterBarButtonItems && isHeaderBarButtonsAvailableForCurrentPlatform
      ? prepareHeaderBarButtonItems(headerCenterBarButtonItems, 'center')
      : undefined;
  const preparedHeaderToolbarItems =
    headerToolbarItems && isHeaderBarButtonsAvailableForCurrentPlatform
      ? prepareHeaderBarButtonItems(headerToolbarItems, 'toolbar')
      : undefined;
  const hasHeaderBarButtonItems =
    isHeaderBarButtonsAvailableForCurrentPlatform &&
    (preparedHeaderLeftBarButtonItems?.length ||
      preparedHeaderRightBarButtonItems?.length ||
      preparedHeaderCenterBarButtonItems?.length ||
      preparedHeaderToolbarItems?.length);

  // Handle bar button item presses
  const onPressHeaderBarButtonItem = hasHeaderBarButtonItems
    ? (event: NativeSyntheticEvent<{ buttonId: string }>) => {
        const buttonId = event.nativeEvent.buttonId;
        const allItems = [
          ...(preparedHeaderLeftBarButtonItems ?? []),
          ...(preparedHeaderRightBarButtonItems ?? []),
          ...(preparedHeaderCenterBarButtonItems ?? []),
          ...(preparedHeaderToolbarItems ?? []),
        ];
        const pressedItem = allItems.find(
          item =>
            item &&
            'buttonId' in item &&
            item.buttonId === buttonId,
        );
        if (
          pressedItem &&
          pressedItem.type === 'button' &&
          pressedItem.onPress
        ) {
          pressedItem.onPress();
          return;
        }
        for (const item of allItems) {
          if (!item || item.type !== 'mailSearchToolbar') {
            continue;
          }
          if (item.filterButtonId === buttonId) {
            item.onFilterPress?.();
            return;
          }
          if (item.composeButtonId === buttonId) {
            item.onComposePress?.();
            return;
          }
          const searchTextChangePrefix = item.searchTextChangeId
            ? `${item.searchTextChangeId}:`
            : undefined;
          if (
            searchTextChangePrefix &&
            buttonId.startsWith(searchTextChangePrefix)
          ) {
            item.onSearchTextChange?.(
              buttonId.slice(searchTextChangePrefix.length),
            );
            return;
          }
        }
      }
    : undefined;

  // Handle bar button menu item presses by deep-searching nested menus
  const onPressHeaderBarButtonMenuItem = hasHeaderBarButtonItems
    ? (event: NativeSyntheticEvent<{ menuId: string }>) => {
        // Recursively search menu tree
        const findInMenu = (
          menu: HeaderBarButtonItemWithMenu['menu'],
          menuId: string,
        ): HeaderBarButtonItemMenuAction | undefined => {
          for (const item of menu.items) {
            if ('items' in item) {
              // submenu: recurse
              const found = findInMenu(item, menuId);
              if (found) {
                return found;
              }
            } else if ('menuId' in item && item.menuId === menuId) {
              return item;
            }
          }
          return undefined;
        };

        // Check each bar-button item with a menu
        const allItems = [
          ...(preparedHeaderLeftBarButtonItems ?? []),
          ...(preparedHeaderRightBarButtonItems ?? []),
          ...(preparedHeaderCenterBarButtonItems ?? []),
          ...(preparedHeaderToolbarItems ?? []),
        ];
        for (const item of allItems) {
          if (item && item.type === 'menu' && item.menu) {
            const action = findInMenu(item.menu, event.nativeEvent.menuId);
            if (action) {
              action.onPress();
              return;
            }
          } else if (item && item.type === 'mailSearchToolbar') {
            const toolbarMenus = [item.filterMenu, item.composeMenu].filter(
              Boolean,
            );
            for (const toolbarMenu of toolbarMenus) {
              const action = toolbarMenu ? findInMenu(toolbarMenu, event.nativeEvent.menuId) : undefined;
              if (action) {
                action.onPress();
                return;
              }
            }
          }
        }
      }
    : undefined;

  return (
    <ScreenStackHeaderConfigNativeComponent
      {...props}
      userInterfaceStyle={props.experimental_userInterfaceStyle}
      headerLeftBarButtonItems={preparedHeaderLeftBarButtonItems}
      headerRightBarButtonItems={preparedHeaderRightBarButtonItems}
      headerCenterBarButtonItems={preparedHeaderCenterBarButtonItems}
      headerToolbarItems={preparedHeaderToolbarItems}
      onPressHeaderBarButtonItem={onPressHeaderBarButtonItem}
      onPressHeaderBarButtonMenuItem={onPressHeaderBarButtonMenuItem}
      ref={ref}
      style={styles.headerConfig}
      pointerEvents="box-none"
      synchronousShadowStateUpdatesEnabled={
        featureFlags.experiment.synchronousHeaderConfigUpdatesEnabled
      }
      consumeTopInset={appliesTopInset}
      consumeLeftInset={consumeLeftInset}
      consumeRightInset={consumeRightInset}
      consumeBottomInset={consumeBottomInset}
      legacyTopInsetBehavior={useLegacyBehavior}
    />
  );
});

ScreenStackHeaderConfig.displayName = 'ScreenStackHeaderConfig';

export const ScreenStackHeaderBackButtonImage = (
  props: ImageProps,
): React.JSX.Element => (
  <ScreenStackHeaderSubview
    type="back"
    style={styles.headerSubview}
    synchronousShadowStateUpdatesEnabled={
      featureFlags.experiment.synchronousHeaderSubviewUpdatesEnabled
    }>
    <Image resizeMode="center" fadeDuration={0} {...props} />
  </ScreenStackHeaderSubview>
);

export const ScreenStackHeaderRightView = (
  props: ScreenStackHeaderSubviewProps & ViewProps,
): React.JSX.Element => {
  const { style, ...rest } = props;

  return (
    <ScreenStackHeaderSubview
      {...rest}
      type="right"
      synchronousShadowStateUpdatesEnabled={
        featureFlags.experiment.synchronousHeaderSubviewUpdatesEnabled
      }
      style={[styles.headerSubview, style]}
    />
  );
};

export const ScreenStackHeaderLeftView = (
  props: ScreenStackHeaderSubviewProps & ViewProps,
): React.JSX.Element => {
  const { style, ...rest } = props;

  return (
    <ScreenStackHeaderSubview
      {...rest}
      type="left"
      synchronousShadowStateUpdatesEnabled={
        featureFlags.experiment.synchronousHeaderSubviewUpdatesEnabled
      }
      style={[styles.headerSubview, style]}
    />
  );
};

export const ScreenStackHeaderCenterView = (
  props: ViewProps,
): React.JSX.Element => {
  const { style, ...rest } = props;

  return (
    <ScreenStackHeaderSubview
      {...rest}
      type="center"
      synchronousShadowStateUpdatesEnabled={
        featureFlags.experiment.synchronousHeaderSubviewUpdatesEnabled
      }
      style={[styles.headerSubviewCenter, style]}
    />
  );
};

export const ScreenStackHeaderSearchBarView = (
  props: ViewProps,
): React.JSX.Element => (
  <ScreenStackHeaderSubview
    {...props}
    type="searchBar"
    synchronousShadowStateUpdatesEnabled={
      featureFlags.experiment.synchronousHeaderSubviewUpdatesEnabled
    }
    style={styles.headerSubview}
  />
);

const styles = StyleSheet.create({
  headerSubview: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerSubviewCenter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 1,
  },
  headerConfig: {
    position: 'absolute',
    width: '100%',
    flexDirection: 'row',
    justifyContent: 'space-between',
    // We only want to center align the subviews on iOS.
    // See https://github.com/software-mansion/react-native-screens/pull/2456
    alignItems: Platform.OS === 'ios' ? 'center' : undefined,
  },
});

#import "RNSFormSheetHostComponentView.h"
#import "RNSDefines.h"
#import "RNSFormSheetContentController.h"
#import "RNSFormSheetContentView.h"
#import "RNSFormSheetContentWrapperComponentView.h"
#import "RNSFormSheetContentWrapperDelegate.h"
#import "RNSFormSheetDetentResolver.h"
#import "RNSFormSheetHostEventEmitter.h"
#import "RNSFormSheetHostShadowStateProxy.h"
#import "RNSFormSheetProviders.h"

#import <React/RCTConversions.h>
#import <React/RCTMountingTransactionObserving.h>
#import <React/RCTSurfaceTouchHandler.h>
#import <react/renderer/components/rnscreens/EventEmitters.h>
#import <react/renderer/components/rnscreens/Props.h>
#import <react/renderer/components/rnscreens/RNSFormSheetHostComponentDescriptor.h>

namespace react = facebook::react;

@interface RNSFormSheetHostComponentView () <RCTMountingTransactionObserving,
                                             RNSFormSheetContentControllerDelegate,
                                             RNSFormSheetContentWrapperDelegate,
                                             RNSFormSheetPresentationProvider,
                                             RNSFormSheetAppearanceProvider,
                                             RNSFormSheetBehaviorProvider>
@end

@implementation RNSFormSheetHostComponentView {
  RNSFormSheetHostEventEmitter *_Nonnull _reactEventEmitter;
  RNSFormSheetHostShadowStateProxy *_Nonnull _shadowStateProxy;

  RNSFormSheetContentController *_Nullable _controller;
  RCTSurfaceTouchHandler *_Nullable _touchHandler;

  // Props
  BOOL _isOpen;
  std::vector<double> _detents;
  BOOL _prefersGrabberVisible;
  BOOL _prefersHorizontalBars;
  CGFloat _preferredCornerRadius;
  NSInteger _largestUndimmedDetentIndex;
  NSInteger _initialDetentIndex;
  BOOL _prefersScrollingExpandsWhenScrolledToEdge;
  BOOL _preventNativeDismiss;
  UIColor *_Nullable _nativeContainerBackgroundColor;

  CGFloat _reactContentsHeight;
}

- (instancetype)initWithFrame:(CGRect)frame
{
  if (self = [super initWithFrame:frame]) {
    [self initState];
  }
  return self;
}

- (void)initState
{
  [self resetProps];
  [self setupController];

  _reactEventEmitter = [RNSFormSheetHostEventEmitter new];
  _shadowStateProxy = [RNSFormSheetHostShadowStateProxy new];
}

- (void)resetProps
{
  static const auto defaultProps = std::make_shared<const react::RNSFormSheetHostProps>();
  _props = defaultProps;

  _isOpen = NO;
  _detents = {};
  _prefersGrabberVisible = NO;
  _prefersHorizontalBars = NO;
  _preferredCornerRadius = -1.0;
  _largestUndimmedDetentIndex = kRNSFormSheetAlwaysDimmed;
  _initialDetentIndex = 0;
  _prefersScrollingExpandsWhenScrolledToEdge = YES;
  _preventNativeDismiss = NO;
  _nativeContainerBackgroundColor = nil;

  _reactContentsHeight = 0.0;
}

- (void)setupController
{
  _controller = [RNSFormSheetContentController new];
  _controller.delegate = self;

  _controller.presentationProvider = self;
  _controller.appearanceProvider = self;
  _controller.behaviorProvider = self;
}

- (void)didMoveToWindow
{
  [super didMoveToWindow];

  if (self.window != nil) {
    [_controller setNeedsPresentationUpdate];
    [_controller flushPendingUpdates];
  }
}

#pragma mark - RNSFormSheetPresentationProvider

- (nullable UIWindow *)hostWindow
{
  return self.window;
}

#pragma mark - RNSFormSheetBehaviorProvider

- (const std::vector<double> &)detents
{
  return _detents;
}

- (CGFloat)reactContentsHeight
{
  return _reactContentsHeight;
}

#pragma mark - RNSFormSheetContentWrapperDelegate

- (void)contentWrapper:(RNSFormSheetContentWrapperComponentView *)wrapper
    didChangeReactContentsHeight:(CGFloat)reactContentsHeight
{
  if (_reactContentsHeight != reactContentsHeight) {
    _reactContentsHeight = reactContentsHeight;
    [_controller setNeedsBehaviorUpdate];
  }
}

#pragma mark - RNSFormSheetContentControllerDelegate

- (void)sheetControllerDidDismiss:(RNSFormSheetContentController *)controller
{
  [_reactEventEmitter emitOnDismiss];
}

- (void)sheetControllerDidNativeDismiss:(RNSFormSheetContentController *)controller
{
  _isOpen = NO;
  [_reactEventEmitter emitOnNativeDismiss];
}

- (void)sheetControllerDidPreventNativeDismiss:(RNSFormSheetContentController *)controller
{
  [_reactEventEmitter emitOnNativeDismissPrevented];
}

- (void)sheetControllerViewDidLayoutSubviews:(RNSFormSheetContentController *)controller
{
  [self ensureTouchHandlerAttached];
  [self syncShadowNodeState];
}

#if !TARGET_OS_TV
- (void)sheetController:(RNSFormSheetContentController *)controller
    didChangeDetentIdentifier:(nullable NSString *)identifier
{
  NSInteger index = [RNSFormSheetDetentResolver detentIndexFromDetentIdentifier:identifier forRawDetents:_detents];
  if (index >= 0) {
    [_reactEventEmitter emitOnDetentChangedWithIndex:index];
  }
}
#endif // !TARGET_OS_TV

- (void)sheetControllerWillAppear:(RNSFormSheetContentController *)controller
{
  [_reactEventEmitter emitOnWillAppear];
}

- (void)sheetControllerDidAppear:(RNSFormSheetContentController *)controller
{
  [_reactEventEmitter emitOnDidAppear];
}

- (void)sheetControllerWillDisappear:(RNSFormSheetContentController *)controller
{
  [_reactEventEmitter emitOnWillDisappear];
}

- (void)sheetControllerDidDisappear:(RNSFormSheetContentController *)controller
{
  [_reactEventEmitter emitOnDidDisappear];
}

#pragma mark - RCTComponentViewProtocol

- (void)updateState:(react::State::Shared const &)state oldState:(react::State::Shared const &)oldState
{
  [super updateState:state oldState:oldState];
  [_shadowStateProxy updateState:state oldState:oldState];
}

- (void)updateEventEmitter:(const facebook::react::EventEmitter::Shared &)eventEmitter
{
  [super updateEventEmitter:eventEmitter];
  [_reactEventEmitter
      updateEventEmitter:std::static_pointer_cast<const react::RNSFormSheetHostEventEmitter>(eventEmitter)];
}

+ (react::ComponentDescriptorProvider)componentDescriptorProvider
{
  return react::concreteComponentDescriptorProvider<react::RNSFormSheetHostComponentDescriptor>();
}

+ (BOOL)shouldBeRecycled
{
  return NO;
}

- (void)mountChildComponentView:(UIView<RCTComponentViewProtocol> *)childComponentView index:(NSInteger)index
{
  [_controller.contentView insertReactSubview:childComponentView atIndex:index];

  // Assuming that for `fitToContents` the RNSFormSheetContentWrapperComponentView will be a direct child of
  // RNSFormSheetHostComponentView.
  if ([childComponentView isKindOfClass:[RNSFormSheetContentWrapperComponentView class]]) {
    ((RNSFormSheetContentWrapperComponentView *)childComponentView).delegate = self;
  }
}

- (void)unmountChildComponentView:(UIView<RCTComponentViewProtocol> *)childComponentView index:(NSInteger)index
{
  if ([childComponentView isKindOfClass:[RNSFormSheetContentWrapperComponentView class]]) {
    ((RNSFormSheetContentWrapperComponentView *)childComponentView).delegate = nil;
  }

  [_controller.contentView removeReactSubview:childComponentView];
}

- (void)updateProps:(const facebook::react::Props::Shared &)props
           oldProps:(const facebook::react::Props::Shared &)oldProps
{
  const auto &oldComponentProps = *std::static_pointer_cast<const react::RNSFormSheetHostProps>(_props);
  const auto &newComponentProps = *std::static_pointer_cast<const react::RNSFormSheetHostProps>(props);

  if (oldComponentProps.isOpen != newComponentProps.isOpen) {
    _isOpen = static_cast<BOOL>(newComponentProps.isOpen);
    [_controller setNeedsPresentationUpdate];

    if (_isOpen) {
      // ALWAYS refresh the sheet configuration when reopening,
      // because UIKit destroys the presentationController after the modal is dismissed.
      [_controller setNeedsAppearanceUpdate];
      [_controller setNeedsBehaviorUpdate];
      // Request the configured initialDetentIndex to be selected
      // again on the fresh presentation controller.
      [_controller setNeedsInitialDetentUpdate];
    }
  }

  if (oldComponentProps.detents != newComponentProps.detents) {
    _detents = newComponentProps.detents;
    [_controller setNeedsBehaviorUpdate];
  }

  if (oldComponentProps.prefersScrollingExpandsWhenScrolledToEdge !=
      newComponentProps.prefersScrollingExpandsWhenScrolledToEdge) {
    _prefersScrollingExpandsWhenScrolledToEdge =
        static_cast<BOOL>(newComponentProps.prefersScrollingExpandsWhenScrolledToEdge);
    [_controller setNeedsBehaviorUpdate];
  }

  if (oldComponentProps.preventNativeDismiss != newComponentProps.preventNativeDismiss) {
    _preventNativeDismiss = static_cast<BOOL>(newComponentProps.preventNativeDismiss);
    [_controller setNeedsBehaviorUpdate];
  }

  if (oldComponentProps.prefersGrabberVisible != newComponentProps.prefersGrabberVisible) {
    _prefersGrabberVisible = newComponentProps.prefersGrabberVisible;
    [_controller setNeedsAppearanceUpdate];
  }

  if (oldComponentProps.prefersHorizontalBars != newComponentProps.prefersHorizontalBars) {
    _prefersHorizontalBars = newComponentProps.prefersHorizontalBars;
#if RNS_IPHONE_OS_VERSION_AVAILABLE(27_1) && !TARGET_OS_TV && !TARGET_OS_VISION
    if (@available(iOS 27.1, *)) {
      [_controller setNeedsUpdateOfVerticalBarConfiguration];
    }
#endif
  }

  if (oldComponentProps.preferredCornerRadius != newComponentProps.preferredCornerRadius) {
    _preferredCornerRadius = newComponentProps.preferredCornerRadius;
    [_controller setNeedsAppearanceUpdate];
  }

  if (oldComponentProps.largestUndimmedDetentIndex != newComponentProps.largestUndimmedDetentIndex) {
    _largestUndimmedDetentIndex = newComponentProps.largestUndimmedDetentIndex;
    [_controller setNeedsAppearanceUpdate];
  }

  if (oldComponentProps.nativeContainerBackgroundColor != newComponentProps.nativeContainerBackgroundColor) {
    _nativeContainerBackgroundColor = RCTUIColorFromSharedColor(newComponentProps.nativeContainerBackgroundColor);
    [_controller setNeedsAppearanceUpdate];
  }

  if (oldComponentProps.initialDetentIndex != newComponentProps.initialDetentIndex) {
    _initialDetentIndex = newComponentProps.initialDetentIndex;
  }

  [super updateProps:props oldProps:oldProps];
}

- (void)invalidate
{
  if (_touchHandler != nil) {
    [_touchHandler detachFromView:_controller.contentView];
    _touchHandler = nil;
  }

  if (_controller != nil) {
    if (_controller.presentingViewController != nil) {
      [_controller dismissViewControllerAnimated:NO completion:nil];
    }
    _controller = nil;
  }
}

#pragma mark - RCTMountingTransactionObserving

- (void)mountingTransactionDidMount:(const facebook::react::MountingTransaction &)transaction
               withSurfaceTelemetry:(const facebook::react::SurfaceTelemetry &)surfaceTelemetry
{
  [_controller flushPendingUpdates];
}

#pragma mark - Layout helpers

- (void)syncShadowNodeState
{
  if (_controller == nil || _controller.contentView == nil) {
    return;
  }

  [_shadowStateProxy updateShadowStateWithBounds:_controller.contentView.bounds];
}

#pragma mark - Touch Handling overrides

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
  // The actual React children are "teleported" and mounted inside a separate view hierarchy (RNSFormSheetContentView).
  // Returning nil ensures that this host view never intercepts touch events meant for the underlying screen.
  return nil;
}

#pragma mark - Touch Handling helpers

- (void)ensureTouchHandlerAttached
{
  if (_touchHandler != nil || _controller == nil || _controller.contentView == nil) {
    return;
  }

  _touchHandler = [RCTSurfaceTouchHandler new];
  [_touchHandler attachToView:_controller.contentView];
}

#pragma mark - Dynamic frameworks support

#ifdef RCT_DYNAMIC_FRAMEWORKS
+ (void)load
{
  [super load];
}
#endif // RCT_DYNAMIC_FRAMEWORKS

@end

Class<RCTComponentViewProtocol> RNSFormSheetHostCls(void)
{
  return RNSFormSheetHostComponentView.class;
}

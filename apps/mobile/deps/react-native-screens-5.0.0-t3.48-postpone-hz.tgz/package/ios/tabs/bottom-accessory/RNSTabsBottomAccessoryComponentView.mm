#import "RNSTabsBottomAccessoryComponentView.h"
#import "RNSTabsBottomAccessoryHelper.h"
#import "RNSTabsBottomAccessoryShadowStateProxy.h"

#if RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE

#import <react/renderer/components/rnscreens/RNSTabsBottomAccessoryComponentDescriptor.h>

namespace react = facebook::react;

#endif // RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE

#pragma mark - View implementation

@implementation RNSTabsBottomAccessoryComponentView {
#if RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE
  RNSTabsBottomAccessoryHelper *_helper API_AVAILABLE(ios(26.0));
  RNSTabsBottomAccessoryShadowStateProxy *_shadowStateProxy API_AVAILABLE(ios(26.0));
  RNSTabsBottomAccessoryEventEmitter *_Nonnull _reactEventEmitter;
#endif // RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE
  RNSTabsHostComponentView *__weak _Nullable _tabsHostView;
  react::RNSTabsBottomAccessoryShadowNode::ConcreteState::Shared _state;
}

- (instancetype)initWithFrame:(CGRect)frame
{
  if (self = [super initWithFrame:frame]) {
    [self initState];
  }
  return self;
}

- (void)initState
{
  static const auto defaultProps = std::make_shared<const react::RNSTabsBottomAccessoryProps>();
  _props = defaultProps;

#if RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE
  if (@available(iOS 26, *)) {
    _helper = [[RNSTabsBottomAccessoryHelper alloc] initWithBottomAccessoryView:self];
    _shadowStateProxy = [[RNSTabsBottomAccessoryShadowStateProxy alloc] initWithBottomAccessoryView:self];
    _reactEventEmitter = [RNSTabsBottomAccessoryEventEmitter new];
  }
#endif // RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE
  _tabsHostView = nil;
}

#pragma mark - UIKit callbacks

#if RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE

- (void)didMoveToWindow
{
  if (self.window != nil) {
    [_helper registerForAccessoryFrameChanges];
  } else {
    [_helper unregisterForAccessoryFrameChanges];
  }
}

#endif // RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE

#pragma mark - RCTViewComponentViewProtocol

#if RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE

- (void)updateState:(const react::State::Shared &)state oldState:(const react::State::Shared &)oldState
{
  [super updateState:state oldState:oldState];
  _state = std::static_pointer_cast<const react::RNSTabsBottomAccessoryComponentDescriptor::ConcreteState>(state);
}

- (void)updateEventEmitter:(const facebook::react::EventEmitter::Shared &)eventEmitter
{
  [super updateEventEmitter:eventEmitter];

  const auto &castedEventEmitter =
      std::static_pointer_cast<const react::RNSTabsBottomAccessoryEventEmitter>(eventEmitter);
  [_reactEventEmitter updateEventEmitter:castedEventEmitter];
}

+ (react::ComponentDescriptorProvider)componentDescriptorProvider
{
  return react::concreteComponentDescriptorProvider<react::RNSTabsBottomAccessoryComponentDescriptor>();
}

#endif // RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE

+ (BOOL)shouldBeRecycled
{
  // There won't be tens of instances of this component usually & it's easier for now.
  // We could consider enabling it someday though.
  return NO;
}

- (void)invalidate
{
  [self invalidateImpl];
}

- (facebook::react::RNSTabsBottomAccessoryShadowNode::ConcreteState::Shared)state
{
  return _state;
}

- (void)invalidateImpl
{
#if RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE
  [_helper invalidate];
  _helper = nil;

  [_shadowStateProxy invalidate];
  _shadowStateProxy = nil;
#endif // RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE

  _state.reset();
}

#pragma mark - React events

#if RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE

- (nonnull RNSTabsBottomAccessoryEventEmitter *)reactEventEmitter
{
  RCTAssert(_reactEventEmitter != nil, @"[RNScreens] Attempt to access uninitialized _reactEventEmitter");
  return _reactEventEmitter;
}

#endif // RNS_TABS_BOTTOM_ACCESSORY_AVAILABLE

#pragma mark - Dynamic frameworks support

// Needed because of this: https://github.com/facebook/react-native/pull/37274
#ifdef RCT_DYNAMIC_FRAMEWORKS
+ (void)load
{
  [super load];
}
#endif // RCT_DYNAMIC_FRAMEWORKS

@end

#pragma mark - View class exposure

Class<RCTComponentViewProtocol> RNSTabsBottomAccessoryCls(void)
{
  return RNSTabsBottomAccessoryComponentView.class;
}

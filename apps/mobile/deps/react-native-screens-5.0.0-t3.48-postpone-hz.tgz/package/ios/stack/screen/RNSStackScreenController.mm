#import "RNSStackScreenController.h"
#import "RNSContainer.h"
#import "RNSContainerItemSupport.h"
#import "RNSHeaderCoordinator.h"
#import "RNSLog.h"
#import "RNSStackHostComponentView.h"
#import "RNSStackNavigationController.h"
#import "RNSStackScreenComponentEventEmitter.h"
#import "RNSStackScreenComponentView.h"

@implementation RNSStackScreenController {
  RNSStackScreenComponentView *_Nonnull _screenView;
  RNSContainerItemSupport *_Nonnull _containerItemSupport;
}

- (instancetype)initWithComponentView:(RNSStackScreenComponentView *)componentView
{
  if (self = [super initWithNibName:nil bundle:nil]) {
    _screenView = componentView;
    _headerCoordinator = [[RNSHeaderCoordinator alloc] initWithScreenController:self];
    _containerItemSupport = [RNSContainerItemSupport new];
  }
  return self;
}

#pragma mark - RNSContainerItem

- (void)registerNestedContainer:(id<RNSContainer>)container
{
  [_containerItemSupport registerNestedContainer:container];
}

- (void)unregisterNestedContainer:(id<RNSContainer>)container
{
  [_containerItemSupport unregisterNestedContainer:container];
}

- (nullable id<RNSContainer>)resolveNestedContainer
{
  return [_containerItemSupport resolveNestedContainer];
}

- (nullable UIScrollView *)findContentScrollView
{
  return [_containerItemSupport findContentScrollViewWithCachedScrollView:[_screenView cachedContentScrollView]
                                                            heuristicRoot:_screenView];
}

- (RNSStackScreenComponentEventEmitter *)reactEventEmitter
{
  return [_screenView reactEventEmitter];
}

#pragma mark - Lifecycle Events

- (void)viewWillAppear:(BOOL)animated
{
  [super viewWillAppear:animated];
  [self.headerCoordinator updateNavigationBarVisibilityAnimated:animated];
#if !TARGET_OS_TV
  [self.headerCoordinator applyToolbarItems];
  [self.headerCoordinator updateToolbarVisibilityAnimated:animated];
  [self.headerCoordinator updateBackButtonMenuEnabled];
#endif // !TARGET_OS_TV
  [[self reactEventEmitter] emitOnWillAppear];
}

- (void)viewDidAppear:(BOOL)animated
{
  [super viewDidAppear:animated];
  [self.headerCoordinator restoreDetachedTitleView];
  [[self reactEventEmitter] emitOnDidAppear];
}

- (void)viewWillDisappear:(BOOL)animated
{
  [super viewWillDisappear:animated];
#if !TARGET_OS_TV
  UISearchController *searchController = self.navigationItem.searchController;
  if (searchController.isActive) {
    searchController.active = NO;
  }
#endif // !TARGET_OS_TV
  [[self reactEventEmitter] emitOnWillDisappear];
}

- (void)viewDidDisappear:(BOOL)animated
{
  [super viewDidDisappear:animated];
  [[self reactEventEmitter] emitOnDidDisappear];
}

- (void)didMoveToParentViewController:(UIViewController *)parent
{
  RNSLog(@"[RNScreens] Screen view with tag=%ld didMoveToParentViewController %@", (long)_screenView.tag, parent);
  [super didMoveToParentViewController:parent];

  if (parent == nil) {
#if !TARGET_OS_TV
    // The pop transition has completed. Clear the back button config this
    // screen has applied onto the screen below. UIKit seems to serialize
    // navigation transitions (undocumented, internal, but seems to work on 18 and 26),
    // so this runs before a queued push applies its own config.
    [_headerCoordinator clearAppliedBackButtonConfig];
#endif // !TARGET_OS_TV

    if (_screenView.activityMode == RNSStackScreenActivityModeDetached) {
      [[self reactEventEmitter] emitOnDismiss];
    } else {
      _screenView.isNativelyDismissed = YES;
      [[self reactEventEmitter] emitOnNativeDismiss];
    }
  }
}

@end

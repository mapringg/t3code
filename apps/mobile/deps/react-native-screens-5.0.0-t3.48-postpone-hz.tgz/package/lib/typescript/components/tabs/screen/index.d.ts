export { default as TabsScreen } from './TabsScreen';
export type * from './TabsScreen.types';
export type * from './TabsScreenIcon.types';
export type * from './TabsScreen.android.types';
export type * from './TabsScreen.ios.types';
//# sourceMappingURL=index.d.ts.map
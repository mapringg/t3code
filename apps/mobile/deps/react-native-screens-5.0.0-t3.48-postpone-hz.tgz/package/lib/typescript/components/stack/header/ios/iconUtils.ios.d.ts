import type { PlatformIconIOS as ResolvedPlatformIconIOS } from '../../../../fabric/header/HeaderItemIOSNativeComponent';
import type { PlatformIconIOS } from '../../../shared/types';
import type { StackHeaderMenuIOS, StackHeaderMenuElementIOS } from './StackHeaderMenu.ios.types';
export declare function resolveIconAssetSources(icon: PlatformIconIOS | undefined): ResolvedPlatformIconIOS | undefined;
export declare function resolveMenuElementIcons(element: StackHeaderMenuElementIOS): StackHeaderMenuElementIOS;
export declare function resolveMenuIcons(menu: StackHeaderMenuIOS): StackHeaderMenuIOS;
//# sourceMappingURL=iconUtils.ios.d.ts.map
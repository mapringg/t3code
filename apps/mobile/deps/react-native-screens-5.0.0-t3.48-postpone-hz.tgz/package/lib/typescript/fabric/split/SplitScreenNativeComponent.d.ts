import type { CodegenTypes as CT, HostComponent, ViewProps } from 'react-native';
type GenericEmptyEvent = Readonly<{}>;
type SplitScreenColumnType = 'column' | 'inspector';
type ActivityMode = 'detached' | 'attached';
type OnDismissEventPayload = Readonly<{
    isNativeDismiss: boolean;
}>;
interface NativeProps extends ViewProps {
    columnType?: CT.WithDefault<SplitScreenColumnType, 'column'>;
    column?: CT.WithDefault<CT.Int32, -1>;
    activityMode?: CT.WithDefault<ActivityMode, 'attached'>;
    screenKey?: string | undefined;
    onWillAppear?: CT.DirectEventHandler<GenericEmptyEvent> | undefined;
    onDidAppear?: CT.DirectEventHandler<GenericEmptyEvent> | undefined;
    onWillDisappear?: CT.DirectEventHandler<GenericEmptyEvent> | undefined;
    onDidDisappear?: CT.DirectEventHandler<GenericEmptyEvent> | undefined;
    onDismiss?: CT.DirectEventHandler<OnDismissEventPayload> | undefined;
}
declare const _default: HostComponent<NativeProps>;
export default _default;
//# sourceMappingURL=SplitScreenNativeComponent.d.ts.map
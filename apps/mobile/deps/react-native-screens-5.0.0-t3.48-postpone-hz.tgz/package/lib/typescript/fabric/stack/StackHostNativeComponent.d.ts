import type { HostComponent, ViewProps, CodegenTypes as CT } from 'react-native';
type StackHostColorScheme = 'inherit' | 'light' | 'dark';
export interface NativeProps extends ViewProps {
    colorScheme?: CT.WithDefault<StackHostColorScheme, 'inherit'>;
}
declare const _default: HostComponent<NativeProps>;
export default _default;
//# sourceMappingURL=StackHostNativeComponent.d.ts.map
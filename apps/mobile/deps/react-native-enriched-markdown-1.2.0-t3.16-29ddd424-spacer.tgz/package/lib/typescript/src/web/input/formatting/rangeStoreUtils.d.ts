import type { RangeBounds } from '../model/rangeBounds';
export declare function sortedInsertionIndex(ranges: readonly RangeBounds[], location: number): number;
//# sourceMappingURL=rangeStoreUtils.d.ts.map
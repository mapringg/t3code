export declare function markdownEscapePositions(text: string): number[];
//# sourceMappingURL=markdownEscape.d.ts.map
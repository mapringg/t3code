import type { MarkdownStyle } from './types/MarkdownStyle';
import type { MarkdownStyleInternal } from './types/MarkdownStyleInternal';
export declare const DEFAULT_NORMALIZED_STYLE: MarkdownStyleInternal;
export declare const normalizeMarkdownStyle: (style: MarkdownStyle) => MarkdownStyleInternal;
//# sourceMappingURL=normalizeMarkdownStyle.web.d.ts.map